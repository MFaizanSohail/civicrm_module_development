<?php

namespace Drupal\civicrm\Exception;

/**
 * Class CiviCRMConfigException.
 */
class CiviCRMConfigException extends \Exception {

}
